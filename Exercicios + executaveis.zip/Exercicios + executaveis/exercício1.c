#include <stdio.h>

int main() {
    int entradapont = -1;
    int pontuacao = 0;
    int inicial = 0;
    char decisao = 'n';
    int c;

    // Leitura e validação da pontuação inicial (>= 0) 
    while (entradapont < 0) {
        printf("Ola, insira a pontuacao inicial do jogador (Sera utilizado apenas a parte inteira >= 0): ");
        if (scanf("%d", &entradapont) != 1) {
            // se não for inteiro, limpar buffer e pedir de novo 
            printf("Entrada invalida. Digite um numero inteiro.\n");
            while ((c = getchar()) != '\n' && c != EOF); // limpa linha. Foi a maneira que achei de impedir entrada de char e float. Tive de pesquisar.
            entradapont = -1;
            continue;
        }
        if (entradapont < 0) {
            printf("Pontuacao invalida. Deve ser maior ou igual a zero.\n");
        }
    }

    inicial = entradapont;
    pontuacao = entradapont;

    printf("\nPontuacao inicial: %d\n\n", pontuacao);

    // Evento 1: Ganhou uma fase (+50) 
    printf("Seu personagem passou de fase? (s/n): ");
    scanf(" %c", &decisao); // espaço antes do %c para ignorar \n 
    if (decisao == 's' || decisao == 'S') {
        pontuacao += 50; // += usado para somar 50 
        printf("Aplicado: +50 -> %d\n", pontuacao);
    } else {
        printf("Nao passou de fase -> %d\n", pontuacao);
    }

    // Evento 2: Coletou item especial (*2) 
    printf("Coletou item especial (x2)? (s/n): ");
    scanf(" %c", &decisao);
    if (decisao == 's' || decisao == 'S') {
        pontuacao *= 2; // *= usado para multiplicar por 2 
        printf("Aplicado: x2 -> %d\n", pontuacao);
    } else {
        printf("Nao coletou item -> %d\n", pontuacao);
    }

    // Evento 3: Perdeu uma vida (-30) 
    printf("Perdeu uma vida? (s/n): ");
    scanf(" %c", &decisao);
    if (decisao == 's' || decisao == 'S') {
        pontuacao -= 30; // -= usado para subtrair 30 
        printf("Aplicado: -30 -> %d\n", pontuacao);
    } else {
        printf("Nao perdeu vida -> %d\n", pontuacao);
    }

    // Evento 4: Bonus de tempo (+15) 
    printf("Recebeu bonus de tempo (+15)? (s/n): ");
    scanf(" %c", &decisao);
    if (decisao == 's' || decisao == 'S') {
        pontuacao += 15;
        printf("Aplicado: +15 -> %d\n", pontuacao);
    } else {
        printf("Sem bonus de tempo -> %d\n", pontuacao);
    }

    // Evento 5: Penalidade por dificuldade (/3) 
    printf("Sofreu penalidade por dificuldade (/3)? (s/n): ");
    scanf(" %c", &decisao);
    if (decisao == 's' || decisao == 'S') {
        pontuacao /= 3; // divisão inteira 
        printf("Aplicado: /3 -> %d\n", pontuacao);
    } else {
        printf("Sem penalidade -> %d\n", pontuacao);
    }

    // Evento 6: Bonus final (+100) 
    printf("Recebeu bonus final (+100)? (s/n): ");
    scanf(" %c", &decisao);
    if (decisao == 's' || decisao == 'S') {
        pontuacao += 100;
        printf("Aplicado: +100 -> %d\n", pontuacao);
    } else {
        printf("Sem bonus final -> %d\n", pontuacao);
    }

    // Resultado final e diferença 
    printf("\nPontuacao final: %d\n", pontuacao);
    int diferenca = pontuacao - inicial;
    if (diferenca >= 0) {
        printf("Diferenca (final - inicial): +%d (ganho)\n", diferenca);
    } else {
        printf("Diferenca (final - inicial): %d (perda)\n", diferenca);
    }

    return 0;
}
