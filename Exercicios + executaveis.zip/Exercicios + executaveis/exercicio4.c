#include <stdio.h>

int main() {
    float peso = 0, altura = 0, IMC = 0;
    int idade = 0;
    char sexo;

    // entrada de dados do usuario
    printf("ola, iremos calcular seu imc e fazer algumas recomendacoes\n");

    // solicita peso
    printf("primeiro, digite seu peso (kg): ");
    scanf("%f", &peso);
    if (peso <= 0) { // validacao de peso
        printf("peso invalido! encerrando programa.\n");
        return 1;
    }

    // solicita altura
    printf("agora, informe sua altura (m): ");
    scanf("%f", &altura);
    if (altura <= 0) { // validacao de altura
        printf("altura invalida! encerrando programa.\n");
        return 1;
    }

    // solicita idade e sexo
    printf("para suas recomendacoes, digite sua idade e sexo (m/f): ");
    scanf("%d %c", &idade, &sexo);
    if (idade <= 0) { // validacao de idade
        printf("idade invalida! encerrando programa.\n");
        return 1;
    }

    // converte sexo para maiuscula para padronizar
    if (sexo >= 'a' && sexo <= 'z') {
        sexo -= 32; // 'a' -> 'A'
    }

    // calcula imc
    IMC = peso / (altura * altura);

    // mostra resultado do imc com 2 casas decimais
    printf("\nseu imc e: %.2f\n", IMC);

    // classificacao do imc
    printf("classificacao: ");
    if (IMC < 18.5) {
        printf("abaixo do peso\n");
    } else if (IMC < 25.0) {
        printf("peso normal\n");
    } else if (IMC < 30.0) {
        printf("sobrepeso\n");
    } else if (IMC < 35.0) {
        printf("obesidade grau i\n");
    } else if (IMC < 40.0) {
        printf("obesidade grau ii\n");
    } else {
        printf("obesidade grau iii\n");
    }

    // recomendacoes personalizadas
    printf("recomendacoes: \n");

    // exercicios conforme sexo e imc
    if ((sexo == 'M') && (IMC >= 25.0)) {
        printf("- homens com sobrepeso/obesidade: praticar exercicios de forca\n");
    } 
    if ((sexo == 'F') && (IMC >= 25.0)) {
        printf("- mulheres com sobrepeso/obesidade: praticar exercicios aerobicos\n");
    }

    // idosos abaixo do peso
    if ((idade >= 60) && (IMC < 18.5)) {
        printf("- idosos abaixo do peso: consultar geriatra\n");
    }

    // jovens com obesidade
    if ((idade <= 25) && (IMC >= 30.0)) {
        printf("- jovens com obesidade: procurar nutricionista\n");
    }

    return 0; // programa terminou corretamente
}
