# include <stdio.h>

int main() {
    int opcao = 0;
    float saldo = 1000.0;
    float deposito, saque, transferencia, taxa;

    while (opcao != 5) { //loop ate digitar 5
        printf("\n--- Caixa Eletronico ---\n");
        printf("1 - Consultar saldo\n");
        printf("2 - Depositar\n");
        printf("3 - Sacar\n");
        printf("4 - Transferencia\n");
        printf("5 - Sair\n");
        printf("Escolha uma opcao: ");
        scanf("%d", &opcao);

        if (opcao == 1) {
            printf("Seu saldo atual: R$ %.2f\n", saldo);
        } 
        else if (opcao == 2) {
            printf("Valor para deposito (min R$0,01): ");
            scanf("%f", &deposito);
            if (deposito >= 0.01) {
                saldo += deposito; //saldo recebe ele + o deposito
                printf("Deposito realizado! Novo saldo: R$ %.2f\n", saldo);
            } else {
                printf("Valor invalido para deposito.\n");
            }
        } 
        else if (opcao == 3) {
            printf("Valor para saque (max R$500,00): ");
            scanf("%f", &saque);
            if (saque > 500) {
                printf("Erro: saque maximo R$500,00.\n");
            } else if (saque > saldo) {
                printf("Erro: saldo insuficiente.\n");
            } else if (saque <= 0) {
                printf("Valor invalido.\n");
            } else { //se nao tiver nenhum problea, entao o saque e realizado
                saldo -= saque;
                printf("Saque realizado! Novo saldo: R$ %.2f\n", saldo);
            }
        } 
        else if (opcao == 4) {
            printf("Valor da transferencia: ");
            scanf("%f", &transferencia);
            if (transferencia > 0 && transferencia <= saldo) {//verificacao basica
                taxa = transferencia * 0.01;
                if (taxa < 2) taxa = 2;// se a taxa for menor que 2, deixa ela com o minimo do negocio
                if (transferencia + taxa <= saldo) { //se a soma de ambos for menor do que tem disponivel, entao ok
                    saldo -= (transferencia + taxa);
                    printf("Transferencia de R$ %.2f realizada (taxa R$ %.2f).\n", transferencia, taxa);
                    printf("Novo saldo: R$ %.2f\n", saldo);
                } else {
                    printf("Erro: saldo insuficiente para cobrir transferencia + taxa.\n");
                }
            } else {
                printf("Valor invalido ou saldo insuficiente.\n");
            }
        } 
        else if (opcao == 5) {
            printf("Saindo do sistema. Obrigado!\n");
        } 
        else {
            printf("Opcao invalida. Tente novamente.\n");
        }
    }

    return 0;
}
