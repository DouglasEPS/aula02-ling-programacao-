#include <stdio.h>

int main() {
    float nota1 = -1, nota2 = -1, nota3 = -1; //-1 para diferenciar do 0 do usuario na hora de conferir
    float freq = -1, media;
    char conceito;

    printf("Iremos calcular a media de notas de um estudante.\n");

    // Leitura com validação
    while (nota1 < 0 || nota1 > 10) {
        printf("Digite a primeira nota (0 - 10): ");
        if (scanf("%f", &nota1) != 1) {
            printf("Entrada invalida. Digite um numero.\n");
            while (getchar() != '\n'); //mesmo sistema do outro exercicio
            nota1 = -1;
        }
    }

    while (nota2 < 0 || nota2 > 10) {
        printf("Digite a segunda nota (0 - 10): ");
        if (scanf("%f", &nota2) != 1) {
            printf("Entrada invalida. Digite um numero.\n");
            while (getchar() != '\n');
            nota2 = -1;
        }
    }

    while (nota3 < 0 || nota3 > 10) {
        printf("Digite a terceira nota (0 - 10): ");
        if (scanf("%f", &nota3) != 1) {
            printf("Entrada invalida. Digite um numero.\n");
            while (getchar() != '\n');
            nota3 = -1;
        }
    }

    while (freq < 0 || freq > 100) {
        printf("Qual a frequencia do estudante (0 - 100): ");
        if (scanf("%f", &freq) != 1) {
            printf("Entrada invalida. Digite um numero.\n");
            while (getchar() != '\n');
            freq = -1;
        }
    }

    // Calculo da media
    media = (nota1 + nota2 + nota3) / 3.0;

    // Determinando conceito
    if (media >= 9.0) {
        conceito = 'A';
    } else if (media >= 7.0) {
        conceito = 'B';
    } else if (media >= 5.0) {
        conceito = 'C';
    } else {
        conceito = 'D';
    }

    // Resultado
    printf("\n--- RESULTADO FINAL ---\n");
    printf("Media: %.2f\n", media); //.2f para mostrar apenas 2 casas
    printf("Conceito: %c\n", conceito);

    if (media >= 5.0 && freq >= 75) {
        printf("Status: Aprovado\n");
    } else if (media < 5.0 && freq >= 75) {
        printf("Status: Reprovado por nota\n");
    } else if (media >= 5.0 && freq < 75) {
        printf("Status: Reprovado por frequencia\n");
    } else {
        printf("Status: Reprovado por nota e frequencia\n");
    }

    return 0;
}

    
    